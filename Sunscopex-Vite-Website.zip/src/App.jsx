
import React from "react";

export default function SunscopeXSite() {
  return (
    <div className="font-sans text-gray-800 bg-white scroll-smooth">
      <section className="min-h-screen bg-gradient-to-br from-orange-100 via-white to-purple-100 flex flex-col justify-center items-center text-center p-8">
        <img src="/logo.png" alt="SunscopeX Logo" className="w-32 mb-4" />
        <h1 className="text-4xl md:text-6xl font-bold mb-4">SunscopeX</h1>
        <p className="text-lg md:text-xl max-w-xl mb-6">High-Impact Advertising. From Print to Pixel.</p>
        <a href="#contact" className="bg-orange-500 text-white px-6 py-3 rounded-full shadow-lg hover:bg-orange-600 transition">Get in Touch</a>
      </section>

      <section className="py-16 bg-white text-center px-6" id="services">
        <h2 className="text-3xl font-bold mb-8">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="p-6 rounded-2xl shadow-xl bg-orange-50">
            <h3 className="text-xl font-semibold mb-2">Outdoor Advertising</h3>
            <p>Billboards, bus wraps, event branding – bold visuals for maximum street-level impact.</p>
          </div>
          <div className="p-6 rounded-2xl shadow-xl bg-purple-50">
            <h3 className="text-xl font-semibold mb-2">Digital Campaigns</h3>
            <p>Social media ads, search marketing, influencer outreach, and geo-targeted content.</p>
          </div>
          <div className="p-6 rounded-2xl shadow-xl bg-orange-100">
            <h3 className="text-xl font-semibold mb-2">Print Solutions</h3>
            <p>Brochures, banners, POS materials designed to convert attention into action.</p>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gradient-to-r from-white to-orange-100 text-center px-6">
        <h2 className="text-3xl font-bold mb-6">Recent Campaign: AU Small Finance Bank</h2>
        <p className="max-w-3xl mx-auto mb-6">From regional billboards to financial literacy workshops and app-based promotions, SunscopeX helped AU Bank create a high-impact launch campaign for their Rajarhat branch.</p>
        <img src="/campaign-visual.png" alt="AU Bank Campaign" className="mx-auto rounded-2xl shadow-xl w-full max-w-3xl" />
      </section>

      <section className="py-16 bg-purple-50 px-6" id="contact">
        <h2 className="text-3xl font-bold text-center mb-8">Contact Us</h2>
        <form className="max-w-xl mx-auto grid gap-4">
          <input type="text" placeholder="Your Name" className="p-3 rounded-lg border border-gray-300" required />
          <input type="email" placeholder="Your Email" className="p-3 rounded-lg border border-gray-300" required />
          <textarea placeholder="Your Message" rows="4" className="p-3 rounded-lg border border-gray-300" required></textarea>
          <button type="submit" className="bg-orange-500 text-white py-3 rounded-lg hover:bg-orange-600 transition">Send Message</button>
        </form>
        <div className="text-center mt-6">
          <a href="https://wa.me/7975368064" target="_blank" rel="noopener noreferrer" className="text-green-600 text-lg underline">Chat with us on WhatsApp</a>
        </div>
      </section>

      <footer className="py-6 text-center text-sm bg-white border-t">
        &copy; 2025 SunscopeX. All rights reserved.
      </footer>
    </div>
  );
}
